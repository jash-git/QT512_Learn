﻿#ifndef ABOUTDLG_H
#define ABOUTDLG_H

#include <QDialog>

class AboutDlg : public QDialog
{
    Q_OBJECT

public:
    AboutDlg(QWidget* parent = nullptr);
};

#endif // ABOUTDLG_H
